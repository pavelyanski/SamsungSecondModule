public class Rectangle extends GeometryObjects{
    double a, b;

    public Rectangle(int a, int b) {
        this.a = a;
        this.b = b;
        square = getSquare();
    }
    public double getSquare(){
        return a * b;
    }

    @Override
    public String toString() {
        return "Rectangle{" +
                "a=" + a +
                ", b=" + b +
                ", square=" + square +
                '}';
    }

    @Override
    void setScale(double scale) {
        a *= scale;
        b *= scale;
        square = getSquare();
    }
}
