public class Circle extends GeometryObjects{
    double radius;

    public Circle(int radius) {
        this.radius = radius;
        square = getSquare();
    }
    public double getSquare(){
        return Math.PI * Math.pow(radius, 2);
    }

    @Override
    public String toString() {
        return "Circle{" +
                "radius=" + radius +
                ", square=" + square +
                '}';
    }

    @Override
    void setScale(double scale){
        radius *= scale;
        square = getSquare();
    }
}
