public class Triangle extends GeometryObjects{
    double a, b, c;

    public Triangle(int a, int b, int c) {
        this.a = a;
        this.b = b;
        this.c = c;
        square = getSquare();

    }
    public double getSquare(){
        double pp = (a + b + c) / 2;
        return Math.sqrt(pp * (pp - a) * (pp - b) * (pp - c));
    }

    @Override
    public String toString() {
        return "Triangle{" +
                "a=" + a +
                ", b=" + b +
                ", c=" + c +
                ", square=" + square +
                '}';
    }

    @Override
    void setScale(double scale) {
        a *= scale;
        b *= scale;
        c *= scale;
        square = getSquare();
    }
}
