public abstract class GeometryObjects implements Comparable<GeometryObjects>{
    double square;
    double scale;
    abstract double getSquare();
    abstract void setScale(double scale);

    @Override
    public int compareTo(GeometryObjects o) {
        if(this.square > o.square){
            return 1;
        } else if(this.square < o.square){
            return -1;
        }
        return 0;
    }
}
