import java.awt.*;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
//        String[] array = new String[]{"5", "3", "7", "10", "2"};
//        StringComparator stringComparator = new StringComparator();
//        Arrays.sort(array, stringComparator);
//        System.out.println(Arrays.toString(array));
//        Socks[] socks = new Socks[]{new Socks(2, Color.CYAN, "cotton"),
//                                    new Socks(3, Color.CYAN, "bamboo"),
//                                    new Socks(2, Color.CYAN, "metal")};
//        Arrays.sort(socks);
//        System.out.println(Arrays.toString(socks));

        GeometryObjects[] geometryObjects = new GeometryObjects[]{new Triangle(3, 4, 5),
                new Rectangle(2, 10),
                new Circle(5)};
        Arrays.sort(geometryObjects);
        System.out.println(Arrays.toString(geometryObjects));
        geometryObjects[1].setScale(3);
        Arrays.sort(geometryObjects);
        System.out.println(Arrays.toString(geometryObjects));

    }
}